import torch.nn as nn
import torch
import math



def to_2tuple(x):
    if isinstance(x, int):
        return (x, x)


class PatchEmbed(nn.Module):
    """
    BERT Embedding which is consisted with under features
        1. TokenEmbedding : normal embedding matrix
        2. PositionalEmbedding : adding positional information using sin, cos
        2. ShapeEmbedding : adding path shape  info

        sum of all these features are output of BERTEmbedding
    """

    def __init__(self, node2vec, embed_dim=128, dropout=0.1):
        """
        :param vocab_size: total vocab size
        :param embed_size: embedding size of token embedding
        :param dropout: dropout rate
        """
        super().__init__()
        # self.token = nn.TokenEmbedding(vocab_size=vocab_size, embed_size=embed_size)
        # self.token = nn.Embedding(90000, 128)
        self.token = nn.Embedding.from_pretrained(node2vec)
        # self.time = nn.Embedding.from_pretrained(time2vec) 
        # self.token = nn.Embedding.from_pretrained(node2vec,freeze=False) 
        # self.time = nn.Embedding.from_pretrained(time2vec,freeze=False)
        # self.rt = nn.Embedding.from_pretrained(roadtype2vec)
        # self.ow = nn.Embedding.from_pretrained(oneway2vec)
        # self.lane = nn.Embedding.from_pretrained(lane2vec)
        # self.rt = nn.Embedding(21, 64)
        # self.ow = nn.Embedding(3,16)
        # self.lane = nn.Embedding(7,32)
        # self.dropout = nn.Dropout(p=dropout)
        # self.norm = nn.LayerNorm(128)
        # self.fc1 = nn.Linear(128,512)
        # self.fc2 = nn.Linear(128,512)


    def forward(self, seq):#, seq_rt, seq_ow, seq_lane):
        # x = self.fc1(torch.cat([self.token(seq), self.time(ts)],dim=2))
        # x = self.fc1(self.token(seq))
        x = self.token(seq)
        # ts_ =self.time(ts)

        # ts_ = self.fc2(self.time(ts))
        # x = torch.cat([self.token(seq), self.rt(seq_rt),self.ow(seq_ow),self.lane(seq_lane)],dim=2)
        return x#, ts_#self.norm(x) ####BNC where c =1


class PositionEmbed(nn.Module):
    def __init__(self, num_patches=100, d_model=128, num_tokens=0):
        super().__init__()

        # Compute the positional encodings once in log space.
        self.num_tokens = num_tokens
        assert self.num_tokens >=0, "num_tokens must be class token or no, so must 0 or 1"
        pe = torch.zeros(num_patches+self.num_tokens, d_model).float()
        pe.require_grad = False

        position = torch.arange(0, num_patches + self.num_tokens).float().unsqueeze(1)
        div_term = (torch.arange(0, d_model, 2).float() * -(math.log(10000.0) / d_model)).exp()

        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)

        pe = pe.unsqueeze(0)
        if torch.cuda.is_available():
            pe = pe.cuda()
        self.register_buffer('pe', pe)

    def __call__(self):
        return self.pe 
    

if __name__ == '__main__':
    # inputs = torch.randn(1, 3, 224,224)
    patchembed = PositionEmbed(d_model=768, num_patchs=196, num_tokens=1)()
    print(patchembed.shape)