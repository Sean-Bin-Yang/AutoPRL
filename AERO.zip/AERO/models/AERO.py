# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.

# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.
# --------------------------------------------------------
# References:
# timm: https://github.com/rwightman/pytorch-image-models/tree/master/timm
# DeiT: https://github.com/facebookresearch/deit
# --------------------------------------------------------
from layers.weight_init import trunc_normal_
from functools import partial
from layers.patch_embed import PatchEmbed, PositionEmbed
from layers.dcl import DCL, DCLW
import torch
import math
import torch.nn as nn
from torch.nn import functional as F
from timm.models.vision_transformer import Block
from utils.pos_embed import get_2d_sincos_pos_embed



def get_1d_sincos_pos_embed(embed_dim, num_patches):
        # num_patches: sequence length
        position = torch.arange(num_patches, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, embed_dim, 2).float() * (-math.log(10000.0) / embed_dim))
        pe = torch.zeros(num_patches, embed_dim)
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        return pe.unsqueeze(0)  # (1, num_patches, embed_dim)

class MultiTaskLossWrapper(nn.Module):
    def __init__(self):
        super(MultiTaskLossWrapper, self).__init__()
       
        self.log_vars = nn.Parameter(torch.zeros(3))  

    def forward(self, loss1, loss2, loss3):
        loss = (
            0.5 * torch.exp(-self.log_vars[0]) * loss1 + self.log_vars[0] +
            0.5 * torch.exp(-self.log_vars[1]) * loss2 + self.log_vars[1] +
            0.5 * torch.exp(-self.log_vars[2]) * loss3 + self.log_vars[2] 
            # 0.5 * torch.exp(-self.log_vars[3]) * loss4 + self.log_vars[3]
        )
        return loss

class Encoder(nn.Module):
    def __init__(self, input_size=128, hidden_size=512, num_layers=2):
        super(Encoder, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.lstm = nn.LSTM(
            input_size,
            hidden_size,
            num_layers,
            batch_first=True,
            bidirectional=False,
        )

    def forward(self, x):
        # x: tensor of shape (batch_size, seq_length, hidden_size)
        outputs, (hidden, cell) = self.lstm(x)
        return (hidden, cell)


class Decoder(nn.Module):
    def __init__(
        self, input_size=128, hidden_size=512, output_size=128, num_layers=2
    ):
        super(Decoder, self).__init__()
        self.hidden_size = hidden_size
        self.output_size = output_size
        self.num_layers = num_layers
        self.lstm = nn.LSTM(
            input_size,
            hidden_size,
            num_layers,
            batch_first=True,
            bidirectional=False,
        )
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x, hidden):
        # x: tensor of shape (batch_size, seq_length, hidden_size)
        output, (hidden, cell) = self.lstm(x, hidden)
        prediction = self.fc(output)
        return prediction, (hidden, cell)

class AERO(nn.Module):

    def __init__(self, 
                 node2vec,
                 input_dim=128,
                 hidden_dim=512,
                 latent_dim=128,
                 output_dim=128,
                 in_chans=3,
                 embed_dim=1024, depth=24, num_heads=16,
                 mlp_ratio=4., embed_layer=PatchEmbed, norm_layer=partial(nn.LayerNorm, eps=1e-6), norm_pix_loss=False):
        super().__init__()

        # --------------------------------------------------------------------------
        
        ####LSTM-VAE 
        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        self.input_size = input_dim
        self.hidden_size = hidden_dim
        self.latent_size = output_dim
        self.num_layers = 1

        ##LSTM AE
        self.lstm_enc = Encoder(
            input_size=self.input_size, hidden_size=self.hidden_size, num_layers=self.num_layers
        )
       
        self.lstm_dec = Decoder(
            input_size=self.latent_size,
            output_size=self.input_size,
            hidden_size=self.hidden_size,
            num_layers=self.num_layers,
        )

        self.fc21 = nn.Linear(self.hidden_size, self.latent_size)
        self.fc22 = nn.Linear(self.hidden_size, self.latent_size)
        self.fc3 = nn.Linear(self.latent_size, self.hidden_size)

        # MAE encoder specifics
        self.patch_embed = embed_layer(node2vec=node2vec, embed_dim=128, dropout=0.)


        self.num_classes=3

        self.cls_token = nn.Parameter(torch.zeros(1, 1, embed_dim))
     
        self.blocks = nn.ModuleList([
            Block(embed_dim, num_heads, mlp_ratio, qkv_bias=True, qk_scale=None, norm_layer=norm_layer)
            for i in range(depth)])
        self.norm = norm_layer(embed_dim)
        # --------------------------------------------------------------------------

        self.norm_pix_loss = norm_pix_loss

        self.criterion_bce = nn.BCEWithLogitsLoss()
        self.criterion_cls = nn.CrossEntropyLoss()
        self.global_T = nn.Parameter(torch.ones(1), requires_grad=True)

        self.dcl = DCL(temperature=5) ##0.05,0.07,0.1,0.5,5
        self.dclw = DCLW(temperature=0.5, sigma=0.5)

        self.clstoken =nn.Linear(128*2,3)
        self.acf = nn.ReLU()

        self.multi_loss_optimize = MultiTaskLossWrapper()

        self.apply(self._init_vit_weights)

    def _init_vit_weights(self, module):
        """ ViT weight initialization
        """
        if isinstance(module, nn.Linear):
            if module.out_features == self.num_classes:
                nn.init.xavier_uniform_(module.weight)
                if module.bias is not None:
                    nn.init.zeros_(module.bias)
            else:
                trunc_normal_(module.weight, std=.02)
                if module.bias is not None:
                    nn.init.zeros_(module.bias)             
        elif isinstance(module, (nn.LayerNorm, nn.GroupNorm, nn.BatchNorm2d)):
            nn.init.zeros_(module.bias)
            nn.init.ones_(module.weight)

    def reparametize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        noise = torch.randn_like(std).to(self.device)

        z = mu + noise * std
        return z

    def get_1d_sincos_pos_embed(embed_dim, num_patches):
        # num_patches: sequence length
        position = torch.arange(num_patches, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, embed_dim, 2).float() * (-math.log(10000.0) / embed_dim))
        pe = torch.zeros(num_patches, embed_dim)
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        return pe.unsqueeze(0)  # (1, num_patches, embed_dim)
    
    def forward_encoder(self, x):
        # embed patches
        # print(x.shape)
        x= self.patch_embed(x)
        B, N, D = x.shape
        
        # add pos embed w/o cls token
        pos_embed = get_1d_sincos_pos_embed(D, x.shape[1]).to(x.device)
        x = x + pos_embed #self.pos_embed[:, 1:, :]
        batch_size, seq_len, feature_dim = x.shape
        xx=x

        ###LSTM-VAE
        enc_hidden = self.lstm_enc(x)
        enc_h = enc_hidden[0].view(batch_size, self.hidden_size).to(self.device)

        mean = self.fc21(enc_h)
        logvar = self.fc22(enc_h)
        z = self.reparametize(mean, logvar)  # batch_size x latent_size

        h_ = self.fc3(z)
        h_ =h_.reshape(-1,h_.shape[0],512)
        
        z = z.repeat(1, seq_len, 1)
        z = z.view(batch_size, seq_len, self.latent_size).to(self.device)
        

        # initialize hidden state
        hidden = (h_.contiguous(), h_.contiguous())
    
        reconstruct_output, hidden = self.lstm_dec(z, hidden)

        x_hat = reconstruct_output
       
        cls_token = self.cls_token.expand(x.shape[0], -1, -1)  # shape: (B, 1, D)
        cls_token = cls_token + pos_embed[:, :1, :]  # 
        cls_tokens = cls_token.expand(x.shape[0], -1, -1)
        x_v1 = torch.cat((cls_tokens, x), dim=1)
        x_v2 = torch.cat((cls_tokens, x_hat), dim=1)

        # apply Transformer blocks
        for blk in self.blocks:
            x_v1_ = blk(x_v1)
            x_v2_ = blk(x_v2)
        x_v1_ = self.norm(x_v1_)
        x_v2_ = self.norm(x_v2_)

        return x_v1_, x_v2_, x_hat, mean, logvar, x

    def forward_test_encoder(self, x):
        # embed patches
        x= self.patch_embed(x)
        B, N, D = x.shape
        
        pos_embed = get_1d_sincos_pos_embed(D, x.shape[1]).to(x.device)
        x = x + pos_embed  
        # append cls token
        cls_token = self.cls_token + pos_embed[:, :1, :]
        cls_tokens = cls_token.expand(x.shape[0], -1, -1)
        x_v1 = torch.cat((cls_tokens, x), dim=1)

        # apply Transformer blocks
        for blk in self.blocks:
            x_v1_ = blk(x_v1)
    
        x_v1_ = self.norm(x_v1_)
      

        return x_v1_

    def loss_function(self, *args, **kwargs) -> dict:
        """
        """
        recons = args[0]
        input = args[1]
        mu = args[2]
        log_var = args[3]

        kld_weight = 0.00025  
        recons_loss = F.mse_loss(recons, input)

        kld_loss = torch.mean(
            -0.5 * torch.sum(1 + log_var - mu**2 - log_var.exp(), dim=1), dim=0
        )

        loss = recons_loss + kld_weight * kld_loss
        return {
            "loss": loss,
            "Reconstruction_Loss": recons_loss.detach(),
            "KLD": -kld_loss.detach(),
        }

    def forward(self, intputs):
        
        x_v1_, x_v2_, x_hat, mean, logvar, x= self.forward_encoder(intputs)

        cls_token_1 = x_v1_[:, 0, :]
        cls_token_2 = x_v2_[:, 0, :]
        loss_dcl_l =[]
        for ii in range(x_v1_.shape[1]-1):
            ll= self.dcl(x_v1_[:, ii+1, :], x_v2_[:, ii+1, :])
            loss_dcl_l.append(ll.cpu())

        ####VAE Loss
        losses=self.loss_function(x_hat, x, mean, logvar)
        loss_vae, recon_loss, kld_loss = (
            losses["loss"],
            losses["Reconstruction_Loss"],
            losses["KLD"],
        )
        ### DCL
        loss_dcl_global = self.dcl(cls_token_1, cls_token_2)
        loss_dcl_local =torch.mean(torch.tensor(loss_dcl_l))
        total_loss =self.multi_loss_optimize(loss_vae ,loss_dcl_global,loss_dcl_local)

        return total_loss
    
    def embed(self, intputs):
        intputs = torch.squeeze(intputs,dim=1)
        latent1= self.forward_test_encoder(intputs)
        x =torch.squeeze(torch.mean(latent1, dim=1),dim=1)
        return x